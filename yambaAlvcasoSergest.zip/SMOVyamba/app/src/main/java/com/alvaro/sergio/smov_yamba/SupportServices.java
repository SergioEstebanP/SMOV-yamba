// Sergio Esteban Pellejero
// Álvaro de Caso Morejón

package com.alvaro.sergio.smov_yamba;

public class SupportServices {

    public static final String CONSUMER_KEY="rqFO2Q3L6HLGusJ43kpLSRh51";
    public static final String CONSUMER_SECRET="JZUmn8jKwJ8af3S9y64O8U0KxY77Uq400F0b6qhU8iCUuYOFHl";
    public static final String ACCESS_TOKEN="1052940451936907264-5embE34o8XzKyjFmXdKcr4rY0GSqAm";
    public static final String ACCESS_SECRET="mMYubNM7VnSNBOPxjN0E8MimVafBYhDRYf1Kcbl7Gxt1s";

    public static final String TAG="MainActivity";

    public static final int MAX_CHARACTERS = 140;

    public static final String MESSAGE_SEND = "Message sent";
    public static final String MESSAGE_SEND_NOT_SEND = "Message not sent";
    public static final String INTERNET_FAIL = "Internet Access OFF";
    public static final String INVALID_CREDENTIALS = "Invalid credentials";
}
